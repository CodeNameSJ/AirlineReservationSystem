package org.AirlineReservationSystem.model.enums;

public enum BookingStatus {
	BOOKED, CANCELLED
}