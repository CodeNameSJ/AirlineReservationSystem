package org.AirlineReservationSystem.model.enums;

public enum SeatClass {
	ECONOMY, BUSINESS
}