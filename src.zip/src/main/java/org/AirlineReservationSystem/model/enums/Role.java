package org.AirlineReservationSystem.model.enums;

public enum Role {
	USER, ADMIN
}