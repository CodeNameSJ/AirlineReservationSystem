package org.AirlineReservationSystem.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.AirlineReservationSystem.model.Flight;
import org.AirlineReservationSystem.model.enums.SeatClass;
import org.AirlineReservationSystem.service.BookingService;
import org.AirlineReservationSystem.service.FlightService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {
	private final FlightService flightService;
	private final BookingService bookingService;

	@GetMapping("/home")
	public String userHome(Model model) {
		model.addAttribute("flights", flightService.findAll());
		return "user/home";
	}

	@GetMapping("/book")
	public String showBookingForm(@RequestParam Long flightId, HttpServletRequest req, Model model) {
		HttpSession s = req.getSession(false);
		if (s == null || s.getAttribute("userId") == null) {
			// save intended URL and redirect to log in
			String url = "/user/book?flightId=" + flightId;
			req.getSession(true).setAttribute("redirectAfterLogin", url);
			return "redirect:/login";
		}
		Flight f = flightService.findById(flightId).orElseThrow();
		model.addAttribute("flight", f);
		return "user/bookingForm";
	}

	@PostMapping("/book")
	public String doBook(@RequestParam Long flightId, @RequestParam int seats, HttpServletRequest req, Model model) {
		HttpSession s = req.getSession(false);
		if (s == null || s.getAttribute("userId") == null) {
			req.getSession(true).setAttribute("redirectAfterLogin", "/user/book?flightId=" + flightId);
			return "redirect:/login";
		}
		var booking = bookingService.createBooking(flightId, SeatClass.ECONOMY, seats);
		model.addAttribute("booking", booking);
		return "user/bookingSuccess";
	}

	// view bookings
	@GetMapping("/bookings")
	public String viewBookings(HttpServletRequest req, Model model) {
		HttpSession s = req.getSession(false);
		if (s == null || s.getAttribute("userId") == null) return "redirect:/login";
		Long userId = (Long) s.getAttribute("userId");
		model.addAttribute("bookings", bookingService.findByUserId(userId));
		return "user/bookings";
	}
}